/*
 * fifo_server : listen on a named pipe; do lookup ; reply
 *               down another named pipe, the name of which
 *               will be sent by the client (in cli.id)
 *               argv[1] is the name of the local fil
 *               argv[2] is the name of the "well-known" FIFO
 */

#include <sys/stat.h>
#include <fcntl.h>
#include <errno.h>
#include <stdlib.h>
#include <string.h>

#include "dict.h"

int main(int argc, char **argv) {
	struct stat stbuff;
	int read_fd,write_fd;
	Client cli;
	Dictrec tryit;

	if (argc != 3) {
		fprintf(stderr,"Usage : %s <dictionary source> ""<resource / FIFO>\n",argv[0]);
		exit(errno);
	}

	/* Check for existence of dictionary and FIFO (both must exist)
	 *
	 * Fill in code. */
	
	if ((stat (argv [1], &stbuff)) == -1){
		printf ("The file %s doesn't exist...\n", argv [1]);
	}
	if ((stat (argv [2], &stbuff)) == -1){
		printf ("The file %s doesn't exist...\n", argv [2]);
	}


	/* Open FIFO for reading (blocks until a client connects)
	 *
	 * Fill in code. */
	if ((read_fd =  open(argv[2],O_RDONLY)) == -1){
		DIE(argv[2]);
	}

	/* Sit in a loop. lookup word sent and send reply down the given FIFO */
	for (;;) {

		/* Read request.
		 *
		 * Fill in code. */
		if(read(read_fd,&cli,sizeof(cli)) == -1){
			DIE("read");
		}
		strncpy(tryit.word,cli.word,WORD);
		//printf("%scat%s:%s%s\n","\x1b[;32;1m",tryit.word,cli.word,"\x1b[0m");

		/* Get name of reply fifo and attempt to open it.
		 *
		 * Fill in code. */
		if((write_fd = open(cli.id,O_WRONLY)) == -1){
			DIE("open cli.id");
		}

		/* lookup the word , handling the different cases appropriately
		 *
		 * Fill in code. */
		switch(lookup( &tryit,argv[1]) ) {
			case FOUND:
				/* Fill in code. */
				write(write_fd,&tryit,sizeof(tryit));
				//printf("%sfind%s:%s%s\n","\x1b[;34;1m",tryit.word,tryit.text,"\x1b[0m");
				break;
			case NOTFOUND:
				/* Fill in code. */
				strcpy(tryit.text,"XXXX");
				write(write_fd,&tryit,sizeof(tryit));
				break;
			case UNAVAIL:
				/* Fill in code. */
				strcpy(tryit.word,"ERROR!");
				strcpy(tryit.text,"server closed.");
				write(write_fd,&tryit,sizeof(tryit));
				DIE("lookup");
		}

		/* close connection to this client (server is stateless)
		 *
		 * Fill in code. */
		if(close(write_fd) == -1){
			DIE("close write_fd");
		}
	}
	if(close(read_fd) == -1){
		DIE("close read_fd");
	}
}
